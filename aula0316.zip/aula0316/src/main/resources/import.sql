insert into produto (descricao, valor) values ('Arroz 5kg',35)
insert into produto (descricao, valor) values ('Feijão 2kg',10)