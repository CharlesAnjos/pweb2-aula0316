package edu.ifto.pweb2.aula0316;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula0316Application {

	public static void main(String[] args) {
		SpringApplication.run(Aula0316Application.class, args);
	}

}
