package edu.ifto.pweb2.aula0316;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula0316ApplicationTests {

	@Test
	void contextLoads() {
	}

}
